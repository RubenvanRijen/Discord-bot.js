const { MessageEmbed } = require("discord.js");


module.exports = {
  name: "example",
  aliases: [""],
  description: "example",
  async execute(message, args, bot) {


  }
};

