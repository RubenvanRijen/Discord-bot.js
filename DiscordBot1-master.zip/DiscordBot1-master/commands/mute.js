const Discord = require("discord.js");
const ms = require("ms");
module.exports = {
  name: "mute",
  aliases: ["d-t"],
  description: "mute a player for a certain time",
  async execute(message, args) {
    const { member, mentions } = message;

  }
};

